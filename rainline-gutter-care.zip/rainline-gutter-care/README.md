# Rainline Gutter Care

A friendly, fall-inspired website for a small gutter cleaning crew in Salem, Oregon. Plain HTML, CSS, and JavaScript. No installation, build process, paid fonts, or framework required.

## Start here

Open **index.html** in your browser to see the landing page. **quote.html** contains the three-step quote flow. Everything needed for the design is included, including the images and logo.

Rainline is an editable sample brand. No phone number, email address, service prices, reviews, or credentials have been invented.

## Upload to GitHub

1. Unzip the download and open the `rainline-gutter-care` folder.
2. Create a GitHub repository, then choose **Add file → Upload files**.
3. Upload the **contents** of this folder, including `assets`. Make sure `index.html` is at the repository’s top level. Do not upload only the ZIP.
4. Commit the files. Open **Settings → Pages**.
5. Under Source, select **Deploy from a branch**. Choose **main** and **/(root)**, then Save.
6. GitHub displays the published address in Pages settings once deployment finishes.

The included `.nojekyll` file disables Jekyll processing. All asset and page links are relative, so the site also works under a repository subpath.

Official instructions: [Create a GitHub Pages site](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site) and [choose a publishing source](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## Turn on real quote requests

**The form currently runs in demo mode. It does not send anything.** The three steps, validation, review edits, and downloadable answer summary work now.

GitHub Pages hosts static files; receiving requests needs a form service. This site includes a Formspree-compatible submission handler.

1. Create your own form in [Formspree](https://formspree.io/) and configure where its submissions go.
2. Open `config.js`. Paste the public form URL into `formEndpoint` and set `demoMode` to `false`.
3. Add your business email and/or phone in the same file. A contact link will appear in the footer.
4. Update `privacy.html` to describe your actual business and form provider.
5. Upload the changes, submit a test request, and verify it arrives in your form dashboard and intended inbox. Check the provider’s spam/CAPTCHA configuration if it fails.

The interface only displays a live submission confirmation after the endpoint responds successfully. A failed request keeps the entered details available for retry. No real inbox was connected or tested during creation.

Use only the public form URL in `config.js`, never a secret API key. See [Formspree’s JavaScript submission documentation](https://help.formspree.io/articles/building-your-form/submit-forms-with-javascript-ajax/).

## Make it yours

| Change | File |
| --- | --- |
| Sample name, footer contact, form connection | `config.js` |
| Hero, services, your story, questions | `index.html` |
| Colors, spacing, mobile layout | `style.css` — colors are at the top |
| Quote questions | `quote.html` |
| Quote behavior | `quote.js` |
| Privacy wording | `privacy.html` |
| Logo and photos | `assets/` |

When changing the name, also update the page titles, descriptions, and home-link accessibility labels in the HTML. The main colors are warm cream `#fffbf4`, burnt orange `#b64e29`, and soft brown `#3c342e`.

The photos are AI-generated illustrations, not your actual crew, customers, or completed jobs. They are labeled as illustrative. Replace them with your own work photos when available; the image prompts and asset notes are in `ASSETS.md`.

Review the proposed service wording before launching. Add genuine reviews and real business credentials only once you have them. No pricing is hardcoded: each home receives a personal quote.
