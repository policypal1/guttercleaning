# Website assets

The two photographs were created with the built-in image generation tool for this website and exported as optimized local JPEGs. They depict illustrative scenes, not actual Rainline jobs or employees. No external image service, font service, or image download is required at runtime.

- `assets/salem-home.jpg`: autumnal Pacific Northwest craftsman home, 1536 × 1024.
- `assets/gutter-cleaning.jpg`: gloved hands clearing a gutter, 1536 × 1024.
- `assets/logo.svg`: original editable gutter-and-raindrop symbol, warm orange and cream.

## Final image prompts

### Home image

Use case: photorealistic-natural. Asset type: premium local gutter cleaning website hero photograph, wide landscape 3:2. Primary request: an extraordinarily beautiful but believable modest Pacific Northwest craftsman home, sage gray-green siding with white fascia, pristine visible white gutters and downspouts, warm wood porch, muted charcoal roof, mature fir trees and Japanese maple in a lush restrained garden, fresh after rain in Salem Oregon. Shot at eye level from slightly across the garden with a 35mm lens, warm soft late-afternoon light filtering through clouds. Crisp material textures, natural editorial architecture photography. House occupies center and right of frame with gutters clearly visible, entire roof ridge has breathing room above. Authentic lived-in understated Oregon home, not mansion or CGI. No people, no cars, no logos, no text, no graphics, no watermark. Rich deep forest foliage and subtle golden sun, high quality.

### Gutter detail

Use case: photorealistic-natural. Asset type: premium gutter cleaning website detail photograph, landscape 3:2. Primary request: close-up editorial photograph along a clean white aluminum rain gutter on a sage-sided Pacific Northwest home. Anatomically realistic hands wearing dark green protective work gloves are carefully lifting a small handful of wet autumn leaves from the gutter into a bucket just outside the bottom of the framing; crop to hands and gutter, no face or body. Charcoal asphalt shingles on left and lush green garden softly out of focus to right. White gutter runs diagonally from lower left to upper right and shows realistic mounting, subtle water droplets, a few leaves farther along. Natural diffuse daylight, tactile surfaces, shallow depth of field, professional home service photography. Clean, believable details, not grime horror. No text, no logos, no watermark.

